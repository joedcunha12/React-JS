

//Local
var envURL = 'http://localhost:3001/'
var reactURL= 'http://localhost:3000/'


//EC2 Instance
//var ip = 'http://13.57.220.117:'
//var reactURL= ip+'3000/'
//var envURL = ip+'3001/'


export{
envURL,
reactURL
}

